@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Bienvenido a Mi Sistema</h1>
    <p>Este sistema está diseñado para gestión administrativa.</p>
    <a href="{{ route('login') }}" class="btn btn-primary">Iniciar Sesión</a>
</div>
@endsection
