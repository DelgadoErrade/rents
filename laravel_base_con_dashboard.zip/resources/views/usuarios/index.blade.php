@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Usuarios</h3>
    <a href="{{ route('usuarios.create') }}" class="btn btn-success mb-3">Nuevo Usuario</a>
    <table id="usuarios" class="table table-bordered">
        <thead>
            <tr><th>ID</th><th>Nombre</th><th>Email</th><th>Acciones</th></tr>
        </thead>
        <tbody>
        @foreach($usuarios as $u)
            <tr>
                <td>{{ $u->id }}</td>
                <td>{{ $u->name }}</td>
                <td>{{ $u->email }}</td>
                <td>
                    <a href="{{ route('usuarios.edit', $u) }}" class="btn btn-sm btn-warning">Editar</a>
                    <form method="POST" action="{{ route('usuarios.destroy', $u) }}" style="display:inline">
                        @csrf @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger">Eliminar</button>
                    </form>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function () {
        $('#usuarios').DataTable();
    });
</script>
@endpush
